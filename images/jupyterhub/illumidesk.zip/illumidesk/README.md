# IllumiDesk Custom JupyterHub LTI Authenticators

## Overview

- JupyterHub compatible Authenticators
- JupyterHub REST API client

## Dev Install

Install in editable mode:

    python3 -m pip install -e .
